### ESE5023 final project 12032350 
# Self Organizing Map (SOM) is a deep learning approach to clustering and/or classification. 
# R version 4.0.3 (2020-10-10)
# Set my R working directory to the location of this file.
setwd("D:/Assignment/R_Project")
# - you will require subdirectories "boundary_files" and "census_data"
### LOAD LIBRARIES - install with:
#install.packages(c("kohonen", "ggplot2", "GGally", "RColarBrewer", "sp")

library(kohonen) #fitting SOMs
library(tidyr)
library(dummies)
library(dplyr)
library(fields)
library(ggplot2) #plots
library(GGally) #plots
library(RColorBrewer) #colors, using predefined palettes
#library(rgdal)  #���о�γ�ȣ�������ͼ
library(psych)


#palettes
contrast <- c("#FA4925", "#22693E", "#D4D40F", "#2C4382", "#F0F0F0", "#3D3D3D") #my own, contrasting pairs
kindofpretty <- c("#B39B66", "#3B3828", "#FAE6B9", "#F2F2F2", "#86BA9F", "#135E1F", "#FFF70A", "#FFB10A", "#0498BD", "#FF780A") #my own

#All the color pallets we have 
display.brewer.all() 

#and then, e.g.:
cols  <- brewer.pal(6, "Set1")
"rev(designer.colors(n=50, col=brewer.pal(9, "Spectral")))"

### -------------- Data processing -------------------------

#Import Data
Keeling_Data   <- read.csv("F_envwater_moni_hour-1.csv",header=T,encoding="UTF-8") 
Data           <- as_tibble(Keeling_Data)

#Describing data 
summary(Data)
#Let's drop the columns which are not useful
keeps <- c("monitor_time", "mn_code" , "pollute_code" , "aver_value" )
Data  = Data[keeps]
summary(Data)

Data   <- Data  %>%
  mutate(md=as.Date(substr(monitor_time,1,10),format='%d/%m/%Y'))  
       
Data = Data[order(Data$md),]
Data   <- Data[838434:1094353,]  #2019��ڶ����ȵ�����
"838434:1094353_20201"
"231362:530283_20193"
write.table(Data,"jidu.csv",row.names=FALSE,col.names=TRUE,sep=",")

head(Data)
#Sort values of mn_code and time 
Data   <- Data  %>%
  mutate(md=as.character(md)) 

Data = Data[order(Data$mn_code),]

head(Data)

#Monitoring station name
(unique(Data[,"mn_code"]))
(unique(Data[,"pollute_code"]))


#remove incomplete samples:
incompletes <- which(!complete.cases(Data))

#where the avr_education_level is NaN - replace with mean
Data$aver_value[incompletes] <- mean(Data$aver_value, na.rm=TRUE)

#recalculate after adjustment
incompletes <- which(!complete.cases(Data))
if (length(incompletes) > 0){
  print(paste0("Removing ", length(incompletes), " data points that have missing values."))
  Data <- Data[-incompletes, ]
}
rm(incompletes)

#Data without time
data  <-  within(Data, rm("monitor_time"))

l = (unique(Data[,"mn_code"]))

l$mn_code[1]
summary(Data)

#COD
data_cod   <-  Data            %>%
  filter(mn_code=="07550088880003")  %>%
  filter(pollute_code=='w01018')  %>%
  mutate(aver_value=ifelse((aver_value==0),NA ,aver_value))   %>%
  summarise(aver_value=mean(aver_value,na.rm=T))  %>%
  mutate(mn_code="07550088880003")

#�ܵ�
data_tn   <-  Data            %>%
  filter(pollute_code=='w21001')  %>%
  filter(mn_code=="07550088880003")  %>%
  mutate(aver_value=ifelse((aver_value<=0|aver_value>80),NA ,aver_value))   %>%
  summarise(aver_value=mean(aver_value,na.rm=T))  %>%
  mutate(mn_code="07550088880003")

#�ܽ���
data_o2   <-  Data                  %>%
  filter(pollute_code=='w01009')    %>%
  filter(mn_code=="07550088880003") %>%
  mutate(aver_value=ifelse((aver_value==-9999|aver_value==1000000000|aver_value==0),NA,aver_value))   %>%
  summarise(aver_value=mean(aver_value,na.rm=T))  %>%
  mutate(mn_code="07550088880003")

#�絼��
data_dd   <-  Data                  %>%
  filter(pollute_code=='w01014')    %>%
  filter(mn_code=="07550088880003") %>%
  mutate(aver_value=ifelse((aver_value<=0|aver_value>20000),NA ,aver_value))   %>%
  summarise(aver_value=mean(aver_value,na.rm=T))  %>%
  mutate(mn_code="07550088880003")

#����
data_nh3   <-  Data                  %>%
  filter(pollute_code=='w21003')    %>%
  filter(mn_code=="07550088880003") %>%
  mutate(aver_value=ifelse((aver_value<=0|aver_value>60),NA ,aver_value))         %>%
  summarise(aver_value=mean(aver_value,na.rm=T))  %>%
  mutate(mn_code="07550088880003")


#Variable name assigned to pollutant name
names(data_o2)[names(data_o2) == "aver_value"]   <- "w01009"
names(data_cod)[names(data_cod) == "aver_value"] <- "w01018"
names(data_tn)[names(data_tn) == "aver_value"]   <- "w21001"
names(data_dd)[names(data_dd) == "aver_value"]   <- "w01014"
names(data_nh3)[names(data_nh3) == "aver_value"] <- "w21003"
	

data_o2  <- dplyr::full_join(data_o2,data_cod,by="mn_code")
data_o2  <- dplyr::full_join(data_o2,data_tn,by="mn_code")
data_o2  <- dplyr::full_join(data_o2,data_dd,by="mn_code")
data_o2  <- dplyr::full_join(data_o2,data_nh3,by="mn_code")

final    <-  data_o2
keeps1 <- c("w01009", "w01018" , "w21001" , "w01014","w21003" )
final  = final[keeps1]

final    <-  final  %>%
  mutate(mn_code="07550088880003")
head(final) 



#дһ��ѭ����ȡÿ��վ�����Ⱦ���ֵ
for(i in 2:33){
  print(l$mn_code[i])
  data1 = Data[ Data$mn_code == l$mn_code[i] , ]
  
  #head(data1)
  #within(data1, rm(mn_code))
  #COD
  data_cod   <-  data1            %>%
    filter(pollute_code=='w01018')  %>%
    mutate(aver_value=ifelse((aver_value==0),NA ,aver_value))   %>%
    summarise(aver_value=mean(aver_value,na.rm=T))  %>%
    mutate(mn_code=l$mn_code[i])
  
  #�ܵ�
  data_tn   <-  data1               %>%
    filter(pollute_code=='w21001')  %>%
    mutate(aver_value=ifelse((aver_value<=0|aver_value>80), NA,aver_value))   %>%
    summarise(aver_value=mean(aver_value,na.rm=T))  %>%
    mutate(mn_code=l$mn_code[i])
  
  #�ܽ���
  data_o2   <-  data1               %>%
    filter(pollute_code=='w01009')  %>%
    mutate(aver_value=ifelse((aver_value==-9999|aver_value==1000000000|aver_value==0),NA ,aver_value))   %>%
    summarise(aver_value=mean(aver_value,na.rm=T))  %>%
    mutate(mn_code=l$mn_code[i])
  
  #�絼��
  data_dd   <-  data1                  %>%
    filter(pollute_code=='w01014')    %>%
    mutate(aver_value=ifelse((aver_value<=0|aver_value>20000),NA,aver_value))   %>%
    summarise(aver_value=mean(aver_value,na.rm=T))  %>%
    mutate(mn_code=l$mn_code[i])
  
  #����
  data_nh3   <-  data1                  %>%
    filter(pollute_code=='w21003')    %>%
    mutate(aver_value=ifelse((aver_value<=0|aver_value>60),NA ,aver_value))   %>%
    summarise(aver_value=mean(aver_value,na.rm=T))  %>%
    mutate(mn_code=l$mn_code[i])
  
  #Variable name assigned to pollutant name
  names(data_o2)[names(data_o2) == "aver_value"]   <- "w01009"
  names(data_cod)[names(data_cod) == "aver_value"] <- "w01018"
  names(data_tn)[names(data_tn) == "aver_value"]   <- "w21001"
  names(data_dd)[names(data_dd) == "aver_value"]   <- "w01014"
  names(data_nh3)[names(data_nh3) == "aver_value"] <- "w21003"
  
  data_o2  <- dplyr::full_join(data_o2,data_cod,by="mn_code")
  data_o2  <- dplyr::full_join(data_o2,data_tn,by="mn_code")
  data_o2  <- dplyr::full_join(data_o2,data_dd,by="mn_code")
  data_o2  <- dplyr::full_join(data_o2,data_nh3,by="mn_code")
  
  
  keeps1 <- c("w01009", "w01018" , "w21001" , "w01014","w21003" )
  data_o2  =  data_o2[keeps1]
  
  data_o2    <-  data_o2  %>%
    mutate(mn_code=l$mn_code[i]) 
  
  final = bind_rows(final,data_o2)
  
}


head(final)  
w <-  unique(final[,"mn_code"])
w
keeps1 = c("w01009","w01014","w21003","mn_code")

final1 = final[keeps1]

summary(final1)

#remove NA values
final1 <- na.omit(final1)
summary(final1)

# ------------------- Correlation ---------------------------


pairs.panels(final1[1:3])


# ------------------- SOM TRAINING ---------------------------

#��һ������ÿ��������ȥ��������ƽ��ֵ���ٳ����������ľ�������(��׼�������Ļ�)
finaldf <- scale(final1[, c(1,2,3)])
finaldf <- as.data.frame(finaldf)
finaldf = dplyr::bind_cols(finaldf,as.data.frame(final1$mn_code))
names(finaldf)[names(finaldf) == "final1$mn_code"]   <- "mn_code"

#choose the variables with which to train the SOM
data_train <- finaldf[, c(1,2,3)]

# now train the SOM using the Kohonen method
data_train_matrix <- as.matrix(data_train)
names(data_train_matrix) <- names(data_train)


som_grid <- somgrid(xdim =4, ydim=7,topo="hexagonal", toroidal = TRUE)  

# Train the SOM model!
set.seed(30) #for reproducability
system.time(som_model <- som(data_train_matrix, 
                             grid=som_grid, 
                             rlen=800, 
                             alpha=c(0.04,0.01),
                             keep.data = TRUE))
summary(som_model)

#a shoot at efficiency
#relating mean distances between units and closest nodes to mean distances between units?
meanD     <- mean(som_model$distances)   #mean distances between codes and the respective closest unit in the map.
meanunitD <- mean(unit.distances(som_grid)) #Distances between units give us a clue on the
#distances prior to the mapping.
AccountedD <- meanunitD - meanD         #MeanD is the distances that are "left over" when we use the map.
#The difference----9 between the distances going in and whats left when we are done are the distances we have accounted for.
#If meandistance is 0 (will never happen), we have a perfect match between units and codes. 
EF <- AccountedD/meanunitD  #Divide the distances accounted for by the mean distances prior to mapping.

#if EF close to 1 ,it's good


# -------------------- SOM VISUALISATION -----------------

#Visualise the SOM model results
# Plot of the training progress - how the node distances have stabilised over time.
## custom palette as per kohonen package (not compulsory)

coolBlueHotRed <- function(n, alpha = 1) {
  rainbow(n, end=4/6, alpha=alpha)[n:1]
}


#the mean distance to the closest codebook vector
plot(som_model, type = "changes")

#counts within nodes(ÿ����Ԫ��Ӧ����������)
plot(som_model, type = "counts", main="Node Counts",shape = "straight", palette.name=coolBlueHotRed)

#map quality (close to 0 = good quality)
plot(som_model, type = "quality", main="Node Quality/Distance",,shape = "straight", palette.name=coolBlueHotRed)

#neighbour distances (shows the sum of the distances to all immediate neighbours)
#This kind of visualisation is also known as a U-matrix plot. Should give you an idea about how to cluster,
#since Units near a class boundary can be expected to have higher average distances to their neighbours.
plot(som_model, type="dist.neighbours", main = "SOM neighbour distances", palette.name=grey.colors,shape = "straight")

#code spread
plot(som_model, type = "codes",codeRendering = "segments")

contrast  <- c("#3D3D3D","#FA4925", "#F0F0F0")
#The lower number of empty cells, the better SOM.
colour1 <- tricolor(som_model$grid, phi = c(pi/6, 0, -pi/6),offset = .5)
plot(som_model, "mapping", bg = rgb(colour1), shape = "straight",col=contrast)


# Plot the heatmap for a variable at scaled / normalised values
var <- 3 #define the variable to plot
plot(som_model, type = "property", property = getCodes(som_model)[,var], main=colnames(getCodes(som_model))[var], palette.name=coolBlueHotRed)

# Plot the original scale heatmap for a variable from the training set:
var <- 1 #define the variable to plot
var_unscaled <- aggregate(as.numeric(data_train[,var]), by=list(som_model$unit.classif), FUN=mean, simplify=TRUE)[,2]
plot(som_model, type = "property", property=var_unscaled, main=names(data_train)[var], palette.name=coolBlueHotRed)
rm(var_unscaled)

#plot a variable from the original data set (will be uncapped etc.)
# This function produces a menu for multiple heatmaps if a factor or character is chosen

plotHeatMap <- function(som_model, data, variable=0){    
  # Plot a heatmap for any variable from the data set "data".
  # If variable is 0, an interactive window will be provided to choose the variable.
  # If not, the variable in "variable" will be plotted.
  
  require(dummies)
  require(kohonen)
  
  interactive <- TRUE
  
  while (interactive == TRUE){
    
    if (variable == 0){
      #show interactive window.
      color_by_var <- select.list(names(data), multiple=FALSE,
                                  graphics=TRUE, 
                                  title="Choose variable to color map by.")
      # check for user finished.
      if (color_by_var == ""){ # if user presses Cancel - we quit function        
        return(TRUE)
      }
      interactive <- TRUE
      color_variable <- data.frame(data[, color_by_var])
      
    } else {
      color_variable <- data.frame(data[, variable])
      color_by_var <- names(data)[variable]
      interactive <- FALSE
    }
    
    #if the variable chosen is a string or factor - 
    #Get the levels and ask the user to choose which one they'd like.
    
    if (class(color_variable[,1]) %in% c("character", "factor", "logical")){
      #want to spread this out into dummy factors - but colour by one of those.
      temp_data <- dummy.data.frame(color_variable, sep="_")
      chosen_factor <- select.list(names(temp_data), 
                                   multiple=FALSE,
                                   graphics=TRUE, 
                                   title="Choose level of variable for colouring")
      color_variable <- temp_data[, chosen_factor]
      rm(temp_data, chosen_factor)
      color_by <- color_variable
    } else {      
      #impute the missing values with the mean.
      color_variable[is.na(color_variable[,1]),1] <- mean(color_variable[,1], na.rm=TRUE)
      #color_by <- capVector(color_variable[,1])
      #color_by <- scale(color_by)  
      color_by <- color_variable[,1]
    }
    unit_colors <- aggregate(color_by, by=list(som_model$unit.classif), FUN=mean, simplify=TRUE)
    plot(som_model, type = "property", property=unit_colors[,2], main=color_by_var, palette.name=coolBlueHotRed,shape = "straight")    
  }
}

finaldf  <-  data.frame(finaldf)
# A menu of all variables should be displayed if variable=0 
# (note on Mac this will required working XQuartz installation.)
plotHeatMap(som_model, finaldf, variable=0)


# ------------------ Clustering SOM results -------------------


# show the WCSS metric for kmeans for different clustering sizes.
# Can be used as a "rough" indicator of the ideal number of clusters
mydata <- getCodes(som_model)
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata,
                                     centers=i)$withinss)
par(mar=c(5.1,4.1,4.1,2.1))
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares", main="Within cluster sum of squares (WCSS)")

# Form clusters on grid
## use hierarchical clustering to cluster the codebook vectors
som_cluster <- cutree(hclust(dist(getCodes(som_model)),method="ward.D2"), 6)

# Show the map with different colours for every cluster						  
plot(som_model, type="mapping", bgcol = cols[som_cluster], main = "Clusters")
add.cluster.boundaries(som_model, som_cluster)

#show the same plot with the codes instead of just colours
plot(som_model, type="codes", bgcol = cols[som_cluster],shape = "straight",main = "Clusters")
add.cluster.boundaries(som_model, som_cluster)






par(mfrow=c(1,1)) # back to one plot
clusterdata <- getCodes(som_model)
wss <- (nrow(clusterdata)-1)*sum(apply(clusterdata,2,var))
for (i in 1:15) {
  wss[i] <- sum(kmeans(clusterdata,centers=i)$withinss)#i range from 1 to no of nodes -1...
}
par(mar=c(5.1,4.1,4.1,2.1)) #par sets or adjusts plotting parameters. Not allways necessary. "mar" = margin.
plot(1:15, wss, type="b", xlab="Number of Clusters", #match i
     ylab="Within groups sum of squares", main="Within cluster sum of squares (WCSS)")

set.seed(30) #for reproducability
fit_kmeans <- kmeans(finaldf[,1:3], 6) #6 clusters are used, as indicated by the wss development.
cl_assignmentk <- fit_kmeans$cluster[som_model$unit.classif] #we have 150 (since grid=15*10) codes with asigned clusters,
#but we have 149 units. The above is to assign units to clusters based on their class-id (code-id) in the SOM model.
final1$clustersKm <- cl_assignmentk #back to original data.


DistanceM <- dist(clusterdata[,1:3], method = "euclidean") #create the distance matrix
fit_hac <- hclust(DistanceM, method="ward.D2") #fit the distances. "D2", since "DistanceM" is not squared.
plot(fit_hac) #display dendrogram. To me, it looks like a 5 or 6 cluster solution.
#in my world 3-5 clusters
HACgroups <- cutree(fit_hac, k = 6) # cut tree into k clusters
# draw dendrogram with red borders around the 6 clusters 
rect.hclust(fit_hac, k = 6, border="grey")

cl_assignmenth <- HACgroups[som_model$unit.classif] #we have 100 (since grid=10*10) codes with asigned clusters,
#but we have 149 units. The above is to assign units to clusters based on their class-id (code-id) in the SOM model.
final1$clustersHac <- cl_assignmenth #back to original data.

final1$trueN <- ifelse(final1$mn_code == "07550088880003", 1, ifelse(final1$mn_code == "44030088880002", 2, ifelse(final1$mn_code == "BW004", 3,
                                                                                                                      ifelse(final1$mn_code == "BW005", 4, 
                                                                                                                             ifelse(final1$mn_code == "BW007", 5,ifelse(final1$mn_code == "BW009", 6, ifelse(final1$mn_code == "BW010", 7,ifelse(final1$mn_code == "BW037", 8,
                                                                                                                                                                                                                                                    ifelse(final1$mn_code == "BW038", 9,
                                                                                                                                                                                                                                                           ifelse(final1$mn_code == "BW039", 10,
                                                                                                                                                                                                                                                                  ifelse(final1$mn_code == "BW041", 11,
                                                                                                                                                                                                                                                                         ifelse(final1$mn_code == "BW042", 12,
                                                                                                                                                                                                                                                                                ifelse(final1$mn_code == "BW044", 13,
                                                                                                                                                                                                                                                                                       ifelse(final1$mn_code == "BW046", 14,ifelse(final1$mn_code == "BW048", 15,ifelse(final1$mn_code == "BW050", 16, ifelse(final1$mn_code == "BW051", 17,ifelse(final1$mn_code == "BW052", 18,
                                                                                                                                                                                                                                                                                                                                                                                                                                                        ifelse(final1$mn_code == "BW062", 19,
                                                                                                                                                                                                                                                                                                                                                                                                                                                               ifelse(final1$mn_code == "BW063", 20,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ifelse(final1$mn_code == "BW070" , 21, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ifelse(final1$mn_code == "BW103" , 22,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ifelse(final1$mn_code == "BW155" , 23,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ifelse(final1$mn_code == "BW165" , 24, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ifelse(final1$mn_code == "BW167" , 25, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ifelse(final1$mn_code == "GL10000000001" , 26, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ifelse(final1$mn_code == "HY001012010001" , 27, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ifelse(final1$mn_code == "MZ010000000001" , 28, 
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ifelse(final1$mn_code == "PS010000000001",29,ifelse(final1$mn_code == "BW016",30,NA )))))))))))))))))))))))))))))) 
        


colour4 <- tricolor(som_model$grid, phi = c(pi/8, 6, -pi/6), offset = 0.03)

final1  <- as.data.frame(final1)

kmeancolor <- final1[,6] #set color indicator
haccolor <- final1[,7] #set color indicator
truecolor <- final1[,5] #set color indicator


plot(som_model, type="mapping", bg = rgb(colour4), shape = "straight", border = "grey", labels = final1[,6],col=cols[haccolor],main = "HAC, mapping, col=cluster, no=cluster")
add.cluster.boundaries(som_model, HACgroups, lwd = 3, lty = 2, col=cols[2]) #name your pallette and choose color...


plot(som_model, type="mapping", bg = rgb(colour4), shape = "straight", border = "grey", labels = final1[,7],col=cols[truecolor], main = "HAC, mapping, col=cluster, no=trueSp")
add.cluster.boundaries(som_model,HACgroups , lwd = 3, lty = 2, col=cols[2]) #name your pallette and choose color...


plot(som_model, type="mapping", bg = rgb(colour4), shape = "straight", border = "grey", labels = final1[,5],col=cols[kmeancolor], main = "Kmean, mapping, col=true, no=cluster")
add.cluster.boundaries(som_model, fit_kmeans$cluster, lwd = 3, lty = 2, col=cols[2]) #name your pallette and choose color...

summary(final1$mn_code) # and with guidens from above plots:

